# Model v3: what changes when truth, time and telling are derived

v2 stored a lot that a store with a turn log would already have. v3 removes it and checks what is lost. The principles:

1. **Events are the truth.** What is true is what happened (events) and what holds (states). Nothing stores that a proposition is true or false.
2. **A claim is content, not a fact.** Someone asserts or believes it. Its verdict is computed from the events and states that bear on it.
3. **Time is anchored to events.** In the product it comes from the turn and round clock. The `when` fields here are the override for events that are not played (backstory, a flashback, a skipped decade). `when.seq` stands in for the clock's order.
4. **Telling is projection.** It is not stored. What the reader knows, and from when, is ordinary knowledge of a person called `reader`, anchored to a paragraph (`para:P07`).
5. **One frame mechanism, used rarely.** `frame` on an event is null for the actual world.

The six conversions are not independent encodings: v3 was converted from v2 and then checked and patched by hand (`v3.py` in the scratchpad is not kept). They inherit v2's fit to these six stories. The seventh work is the first direct encoding; see the last section.

## The shape (`v3/story.json`)

| Key | Holds |
|---|---|
| `entities`, `time` | As v2. |
| `events` | As v2, with `frame` only for the one vision, `claims` (ids of claims, or of events and states, that the event asserts), `origin` (omitted = played; `offscreen`, `backfilled`). The six conversions also carry `basis` (omitted = stated; `implied`, `reported`); the later works dropped it (see below). Diary entries are events of kind `writes`. |
| `states` | Now with ids. Holds what v2 kept as always-true facts (`circumstance`). Knowledge can be of a state. |
| `claims` | `{id, text, about, bears_on: [{ref, as}]}`; `as` is `confirms`, `contradicts` or `disputes`; `ref` is an event, state or reading. No truth field. The later works use `confirms`, `contradicts`, `supports`, `undermines` (no `disputes`), events only, and add `by`, `asserted_in`, `cites` and `parts` (below). |
| `held` | What a person anticipates or imagines, with the moment it is held. |
| `knowledge` | Who knows, believes, doubts or is unaware of an event, state, claim or held item; no accuracy field. |
| `readings` | Interpretations, including the narrator's hypotheticals and counterfactuals (`kind`). |
| `frames` | Only kinds that need a sequence of non-actual events. |

Verdict of a claim (`validate.spec.ts`): confirmed and contradicted both: disputed; contradicted only: false; confirmed only: true; only `disputes`: disputed; nothing: unresolved. A belief's accuracy is the verdict of its claim.

## What was removed, and where it went

| v2 | v3 |
|---|---|
| `facts` with truth spans (50) | 29 became events or states that knowledge points at; 21 became claims, and one claim (Della's reading of Jim's stare) was added |
| `telling` segments and entries | Dropped. Diary entries are `writes` events. Order of telling is derivable from `src` against `when.seq`. |
| 8 frame kinds | One survives (Owl Creek's vision). Anticipation, daydream: `held`. Hypothetical, counterfactual: readings. Told fiction: the speech event's claims. Perceived-unsettled and suspicion: ordinary events plus an unresolved claim. |
| `status` | `origin` (and `basis` in the six conversions) |
| `knowledge.accuracy` | Derived |

## Results

| | E | S | N | P |
|---|---|---|---|---|
| v1 (427 units) | 128 | 207 | 65 | 27 |
| v2 | 288 | 95 | 29 | 15 |
| v3 | 278 | 97 | 29 | 23 |

| Questions (75) | yes | partly | no |
|---|---|---|---|
| v1 | 10 | 38 | 27 |
| v2 | 69 | 5 | 1 |
| v3 | 64 | 9 | 2 |

v3 gives up 10 encoded units and 5 questions against v2. Eight of the lost units are telling rows that moved to projection, as intended, and two became free text. The rest is below.

## Findings

- **Derived verdicts match.** Of the 21 claims that came from v2 facts, 20 derive the verdict v2 stored. The one that differs is the Open Window's coat: v2 said "contradicted", v3 derives true. The coat is real; what is wrong is Framton's inference from it. v2 had mixed a claim's truth with a character's misreading.
- **A belief's accuracy needs a bearing event.** The verdict is only as good as the `bears_on` links, which I chose by hand. `disputes` (a reading contests it) is the weakest: it carries three claims (the Hour's cause of death, John's diagnosis and her "better"). In a product these would come from the keeper, or stay unresolved.
- **Unknown is the absence of a bearing event.** The woman in the wallpaper, the scout's trap and the driftwood are unresolved because nothing bears on them. That is the right reading, and it means "unknown" needs no field.
- **Anticipations lose "did not happen".** A held item has no `realised_by`, so "Louise never wept over his body" is only an absence. Two questions fell to partly. A closed-world rule (a held item with no realising event by the end is unrealised) would fix it, but it is a rule about when a story is over.
- **Frames are rarer than v2 suggested.** One of the eight kinds needed a sequence of non-actual events: a vision or a dream (the product's `/dream` is the same thing). Everything else was a belief, an intent, a claim or a reading.
- **Telling was hiding gaps.** With segments gone, seven paragraphs of the Yellow Wall Paper (the garden, her musings, a transition) were in no record. v2's telling covered them. They became states and claim sources, or are exempt (section numbers, a transition).
- **Telling order is derivable.** Comparing the paragraph of an event's `src` with its `when.seq` finds the analepses: the Hour's newsroom events, the Owl Creek's backstory. No stored field was needed.
- **Narrator hypotheticals become text.** The Queen of Sheba and the necklace what-if are readings with text only. This is the one place v3 holds less than v2.
- **Voice has no home.** Focalisation and "when is the man named" are not answerable. Both are narration, which the stored turn already is.

## Changes tried on a fresh work (the Speckled Band)

After the six conversions, the changes below were tried by encoding a seventh work directly in v3 (`speckled-band/`, with its own README). Together they are what I would call v3.1. The six earlier encodings were not changed and still use the v3 form above.

| Change | Outcome |
|---|---|
| `basis` dropped, `origin` only | Not missed. Who vouches for an event is carried by knowledge rows (`how: told`, `source`). |
| `established_in` on backfilled and offscreen events | Added. A past event bears on claims from the scene that established it, not from when it happened. |
| `disputes` dropped | Not missed. |
| `supports` and `undermines` added beside `confirms` and `contradicts` | Needed. 32 of 41 links are weak and 15 of 24 claims have no strong one. New verdicts: `likely`, `unlikely`, `open`. |
| Claims carry `by` and `asserted_in`; a link counts from the later of the claim and the event | Needed. A third of the links are evidence recorded before the claim, so a keeper looks both ways. Verdicts can be read at any moment (`verdict_at`). |
| Held items: `fulfils` and `prevents` from events, otherwise open | Right. No closed-world rule; Helen's wedding is open. |
| Concealment: event kind `conceal` with `from` | Enough to answer who hid what from whom; effect is not recorded because the text does not. |
| Simultaneity: events carry `when.t`; overlap is derived | Works where a clock exists; the night of Julia's death has order only. |
| Telling order: first paragraph of `src` against `when.seq` | Works if events are split at paragraph boundaries. |

Rival claims, conditions, bad faith and compound claims were tried afterwards (below). Still not solved: a doubt voiced by the claimant must be a stance, not a link; the narrator's endorsement has no home yet (see Proposals).

## Still open

- Strength of evidence: `supports` is one step; nothing says one clue from five.
- Whether the narrator's endorsement is an event, a reading or a status of a claim.
- Who writes the links in play. The Speckled Band shows what the keeper has to do (both directions, weak and strong), not whether it does it well; that needs a run with a model.
- Numeric relationships and acted feeling are v1's (`public_state` against `inner_state`); neither version here carries them.
- Simultaneity among many named individuals in one place, and what to derive from `possible` overlap (tested across places on Dracula, Chapter VII).
- Deadlines and amounts on held items (see Proposals).

## Rival claims (tried on the Speckled Band)

A top-level `questions` list names sets of mutually exclusive claims: what killed Julia (fear, gypsies, the snake), what made the clang (shutter bar, safe door), what the band was (gypsies, the snake). The rule: when a rival derives `true` from its own bearings, this claim gets a `contradicts`; when a rival derives `likely`, it gets an `undermines`. Only a rival's own bearings count, never its rival-adjusted verdict, so no cycle is possible, and a rival that is `false` never lifts the others, so a question whose answers are not all listed is safe. Two rivals that are both `likely` leave each other `open`.

Result: on the Speckled Band the rule changed one verdict: Julia's death from fear goes from `unresolved` to `unlikely` once Holmes suspects the snake. On Much Ado it decided one outright: Don John's feigned regard for Claudio has no bearings of its own and derives `false` only because its rival, his admitted spite, derives `true`.

Limits: the set must be written by whoever writes the claims (a keeper pass would have to notice that two claims answer one question); a claim that is only partly exclusive (gypsies involved alongside the snake) would be wrongly undermined.

## Second round: Much Ado About Nothing (an ensemble), and what was built from it

Encoded directly in v3 with the answer key written before the links. The first pass caught two key errors of mine, three encoding slips and two real gaps in the model; the findings were then built and checked on both fresh works. The second-round checks were written after the encoding and are not blind.

| Finding | What the model has now |
|---|---|
| Concealment from several people | `from` on a `conceal` event takes a list. |
| Order with no clock | Events carry a `scene`; events of one scene are ordered by their text order; across scenes only stated `after`/`before` relations count. Two events with no relation are `unordered`, as the text leaves them. |
| Who heard a line | `audience` on an event overrides presence: otherwise the parties hear it, and so does anyone whose `concealment` state covers it. `audience` is the encoder's inference when the text does not say (the transcription has no aside markers). It is the same information as v1's `perceived_by`. |
| Not knowing | Derived: a person who was not a party, not within hearing and not told does not know. Eleven of 43 `unaware` rows were removed. |
| Conditions | A held item takes `if` (other held items). Outcome: `fulfilled`, `prevented`, `void`, `waiting` or `open`. |
| A lie told on purpose | A check, not a field: the asserter, when asserting, was a party to an event (or holds a `knows` row) that contradicts the claim or confirms its rival. Presence as an overhearer does not count: Benedick has the evidence against "no trick" and misreads it. A backfilled event (`b-gull-planned`) records that Leonato knew before he spoke. |
| A claim's absent source | `cites` on the claim; the check derives that the cited person never spoke before it. |
| A feeling caused by a false claim | `causes` between events; the check follows them to a claim that derives untrue. |
| Compound claims | `parts`, each with its bearings (Speckled Band); the whole derives `mixed` when parts differ. |
| False beliefs at a moment | A `believes` row active at a moment against the claim's verdict at that moment. |
| Simultaneity | Not tested: a play has no clock. |

Details and the corrections to my own key are in `much-ado/README.md`.

## Third round: Dracula, Chapter VII (several places, one night), read for play

Encoded directly in v3 with the key written before any record. Everything the key predicted held except two entries of mine; the check then showed one real gap, two clocks for a verdict.

| Finding | What the model has now |
|---|---|
| A verdict has two clocks | `verdict_at(moment)` is the record's view; every event told by a later document (the voyage, read in the log) enters the record at once. `verdict_for(person, moment)` counts only the bearings the person knows at that moment (party to the event, or told). The captain thinks the stranger unlikely after the search and open after the mate's account. Rival adjustment is not applied to `verdict_for` yet. |
| Simultaneity | Derived from `when.t` inside one time base (`when.epoch`); three answers: `definite`, `possible` (an undated event that is only `within` a dated one) and `none`. Different bases are `none`, never derived. |
| Time bases that do not meet | Four in one chapter. When the text's own dates conflict (the storm is 'last night' on 8 and the arrival 'last night' on 9 August), the conflict is two open claims, not a resolution. |
| A sleeper | The party rule yields to an `unaware` row (how: asleep). |
| Crowds | A group is one entity: nobody in it has a row. A scene with a crowd needs someone in it to see things. Not solved. |

Roleplay lens (the owner's reminder, applied from here on): findings are rated for what play needs, and the questions of each new work carry that rating. From this chapter, needed in play: the character's own verdict, possible overlap (alibis), open hooks, the sleeper override, and the crowd. Analysis only: telling order and layers of provenance. Details in `dracula-whitby/README.md`.

## Proposals on the open questions

These are my recommendations; each says what it would take and what would change my mind. None is built unless stated.

1. **Which of this goes into the real model.** Take first what needs no model to write: events and states, held items with `fulfils`/`prevents`/`if`, concealment, and who perceived what (`audience` is v1's `perceived_by`, already written by the game master). Defer claims with derived verdicts until the keeper experiment below shows it can write the links. Reason: everything derived here is only as good as the links and rows someone writes, and so far I wrote all of them.
2. **Who writes the links.** An experiment, not a decision: give a model the Speckled Band event by event, ask it to write claims and bearings with a tool, and score against `v3/story.json`: precision and recall of strong bearings, of weak ones, and of the both-ways pass, three runs on the 35B, with the 27B only if the 35B fails for capacity. Cost: a harness in `tests/benchmark` and a few hours of model time. If recall of strong bearings is under about two thirds, keep claims out of the keeper's job and let the game master write them only for plots.
3. **Strength of evidence.** Keep two levels. Do not add weights. Report the number of supporting and undermining links beside the verdict (derived, no field), so "likely on one clue" is visibly different from "likely on five".
4. **The narrator's endorsement.** An event of kind `narration` by the narrator, bearing `confirms`, when a narrator vouches ("Such are the true facts of the death of Dr. Roylott"). In the Speckled Band the line vouches only for Roylott's death, which the model already holds `true`; Julia's cause stays `likely`, as the text leaves it. So the first report overstated this as a gap. A play has no narrator, so nothing there to model.
5. **Deadlines and amounts.** A deadline is `by` on a held item naming an event or a clock time; the outcome becomes `lapsed` when it passes unfulfilled. An amount is v2's `effects` (transfer, adjust) on the event that pays; the fee's condition is `if`. Not built: it needs a work with a clock and money in the foreground (the Gift of the Magi has both but is in the six conversions).
6. **Numeric relationships.** Keep them in v1's `variables`; the experiments never needed a number to answer a question about who knew or what was true.
7. **Acted feeling.** No field. An acted feeling is an event whose actor knew better, the same derivation as bad faith: Beatrice's scorn at the dinner message, Claudio's mock sympathy and Don John's "plague prevented" all fit. Test it when a work makes the feeling itself the question.
8. **Simultaneity across places.** Tested on Dracula, Chapter VII (done; see the third round). It works inside one time base with three answers (definite, possible, none); it does not tie bases that the text itself does not tie. What is still untested is simultaneity among many named individuals in one place (a crowd with its own views), and anything derived from `possible` (who could have seen what).
9. **What play reads each turn.** From the three fresh works, the pieces a character agent or a game master could take without a keeper writing claims: who was a party, within hearing or told (`knows_at`), who is a sleeper (`unaware`), possible overlap, open and waiting held items, and a character's own verdict on a claim (`verdict_for`). All of them are derived from events, rows and held items that the game master already writes (`perceived_by`, sleep, holds, held outcomes), except `verdict_for`, which needs claims and bearings: build the first five first.

## Fourth round: the keeper-links experiment (Speckled Band)

Blind model keepers wrote the claims layer from events and text (`keeper-links/`). Given my claim texts and the whole story, one keeper's links gave the same verdict as my key on 12 of 24, a different strength on 9, settled-vs-open on 2, and flipped one. A keeper that sees the story only slice by slice (three chains of four steps) gave 13-15 of 24 the same, 3-7 settled-vs-open, and one flip in 72 verdicts. Writing its own claims, a keeper found the central ones (11 of its 19 matched mine) and skipped the small clue claims. Errors: assertion events used as decisive proof (whole-story run), and a wrong sign on a link (a chain). Capping assertion events at supports/undermines did not reliably help, so it is not proposed. Left for play: a keeper over-links (about twice my links), so a settled verdict from model-written links should need two decisive links; a second pass asking each decisive link its sign is untested; claim detection per scene is the bigger gap.

## Fifth round: the remaining parts

Built and tested (all after the fact except where noted; each has a negative control):
- **`verdict_for` with rivals and `parts`.** A person's own view of a claim now uses the same rules as the record's view (compound `parts`, rival adjustment) over only the bearings that person knows. A rival that is only unlikely never lifts the others. Pinned on the Speckled Band (Holmes at the lash: the gypsies unlikely through the snake rival; Helen with only the shutter test: still unresolved).
- **Groups.** A group can declare `may_include` (persons or groups); a person in it who is not named in an event gets `possibly` knows (`knows3`: knows, possibly, no) for what the group witnessed. In Dracula only the boat captains qualify from the text; the fisherman and the coal merchant stay `no`. Crowd membership is still declared by the keeper or game master, not derived.
- **Deadlines and amounts.** A held item may carry `due` (a time in the events' own clock), `amount`, `payer` and `payee`. Derived: `overdue` (the deadline passed on one view and nothing fulfils it) on the record's view versus the world's view, `on-time` or `late` once fulfilled, and what a person owes (`due` or `conditional`). Spec: Helen's noon train; Don John's thousand ducats owed only if the staging happens. `overdue` is not `lapsed`: a silent text does not mean the thing did not happen.
- **Ties between time bases.** `time.ties` map one base onto another under a claim. The two Dracula date readings give the same order but different gaps: the dog found dead about 250 minutes after the leap under one reading, 1690 under the other; both readings are shown with their verdicts (both open).

Keeper findings (`keeper-links/`): see its README. In short, not ready to feed verdicts to the game master; usable as suggestions.

Still open: derived crowd membership; the 35B keeper's quality on a real play transcript through the real keeper prompt (this used constrained JSON over events, not the product's tools); a pairwise exclusivity check for rival sets (only a size cap tested); whether a second model asking "which theories compete here" recovers the missing rival theories.
