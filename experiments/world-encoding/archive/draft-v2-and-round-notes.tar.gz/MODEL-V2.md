# Model v2 (`history/1`): what six short stories asked of it

This is an experiment, not a design. Nothing in the code reads these files. v2 is a JSON shape I changed as each story demanded, to see what a store would have to hold to keep the story and to answer questions about it. It was fitted to these six works, so its good scores say it can express them, not that it is complete. The next step is to decide, from the gaps below, what (if anything) the real model should take.

v1 means the project's current formats: world files plus records edits (`events`, `perceived_by`, `beliefs`, `item_changes`, `variable_changes`, `relationships`, and the rest of `parseRecordsEdit`). Every v1 encoding here loads with the project's own loaders and its history applies to a real story store, so v1 shows what the current model can do with no change.

## The shape

One `story.json` per work:

| Key | Holds |
|---|---|
| `work` | Title, author, year, path of the source text. |
| `time` | `anchors` (named points that can be partial: `--12-24`, `--01-18` with a weekday, or unknown), `spans` (named stretches with an approximate length and where the length came from). |
| `entities` | `people`, `places`, `things`. Same idea as v1, but `unnamed: true` marks someone or somewhere the text never names, and a place can be missing. |
| `frames` | Kinds of reality other than the actual one: `anticipation`, `hypothetical`, `counterfactual`, `fantasy`, `suspicion`, `told-fiction`, `hallucination`, `perceived-unsettled`. A frame has an owner, optionally a parent, and may start and end at events. |
| `facts` | Propositions with a `truth` that can change over time: `true`, `false`, `unknown`, `disputed`, `contradicted`. |
| `events` | What happens (see below). |
| `knowledge` | Who holds which fact or event, as `knows`, `believes`, `doubts` or `unaware`, from when to when, how they got it, from whom, and whether they are right (`accuracy`). `reader` is a person too. |
| `states` | Things that hold over a stretch: location, holder, feeling, appearance, cash, habit, concealment. |
| `readings` | Interpretations, held by the narrator, a character or the reader, marked `stated`, `implied` or `ambiguous`. |
| `telling` | The discourse, kept apart from the world: the narrator, the diary `entries`, and `segments` (which paragraphs, what mode, which events, which facts they `reveal` or `withhold`). |
| `gaps_found` | What v1 could not hold for this story. |

An event has: `id`, `when`, `kind`, `place`, `text`, `who` (with roles), `src` (paragraphs), and as needed `things`, `says` (what was said), `manner`, `intent`, `importance`, `causes` (`stated` or `implied`), `claims` (facts the event asserts), `frame` and `realised`, `fulfils`/`fulfilled_in`/`grounded_in` (links between a vision and what it comes from), `effects` (`transfer`, `adjust`, `set`, `move`), `frequency: iterative`, `status` (`implied`, `reported`, `stated-afterwards`, `partly-implied`), `reported_by`, `terms`/`expires`, `foregoes`. `when` has an `ord` (rank in story order, only for sorting), and any of `at` (partial dates allowed), `precision`, `approx`, `after`/`before`/`within` (events or anchors), `gap`, `duration`.

A reader of v2 should be able to answer, without reading prose: when was this, in what order was it told, who knew it then, was it true, and was it real or imagined.

## How v2 changed, work by work

The order is the order they were encoded.

1. **The Story of an Hour.** Began with `facts` and `knowledge` (a false report believed by three people), `states` for inner feeling over time, `readings` for an implied cause of death, and `telling` for a fact withheld to the last paragraphs. Added `says` and `manner` when speech turned out to be content, not a detail of style. Added `frames` for the futures Louise imagines and never has.
2. **The Gift of the Magi.** Added `effects` (money and a swapped pair of possessions), `iterative` events for habits, `reported` events (Jim's afternoon is only ever told by Jim), partial dates, and `hypothetical` frames. Showed that v1 needs invented people and places for things the text leaves unnamed.
3. **An Occurrence at Owl Creek Bridge.** Added the `hallucination` frame with a felt length and a real length, `grounded_in` (the vision is built from the noose and the neck breaking), `fulfils` (the vision enacts his plan), truth `unknown` for a claim nobody can check, and reader knowledge by segment (`seg:s07`).
4. **The Open Window.** Added `told-fiction` frames whose parts are checked claim by claim (some true, some false), `misreading_of` (a true remark taken as proof of a false story), `poses`, and an annotation for a performance. Animals appeared (`kind: animal`).
5. **The Necklace.** Added `agreement` with `terms` and `expires`, `foregoes`, an event with no place and an explicit note (`e-loss`), a holder who is `unknown`, a `counterfactual` frame, `summarised` events with long durations, and a weekday-and-date anchor with no year.
6. **The Yellow Wall Paper.** Added `telling.entries` (a diary is a telling device with its own times), the `perceived-unsettled` frame (the text never says the woman in the wallpaper is not there), the `suspicion` frame, a `concealment` state, and an `ambiguous` reading (the name 'Jane').

By the last two the changes were small. That is a sign the shape is settling for stories of this kind, but all six were short fiction told by one narrator, so it says nothing yet about ensembles, simultaneity across many places, or a long frame narrative.

## Consolidated gaps in v1

| What v1 cannot hold | Seen in | v2's answer |
|---|---|---|
| An event's own time: unknown, approximate, relative, an interval, a deadline. `starting_time` must be an instant, so a year was invented in every work. | all six | `when`, `time.anchors`, `time.spans` |
| The order of telling against the order of happening. | all six | `telling.segments`, `telling.entries` |
| That a report or belief is false, or that its truth is unknown. A belief has no accuracy; only a perception does. | all six | `facts` with `truth`, `claims`, `knowledge.accuracy` |
| What the reader knows and when. | all six | `knowledge` rows for `reader`, `reveals`/`withholds` |
| Events that are not actual: imagined futures, a vision, a story told by a character, a supposition, a what-if. | all six | `frames`, `realised`, `fulfils`, `grounded_in` |
| An event the text only implies or reports later (a death, a haircut, a capture, an offstage afternoon). v1 had to invent an ordinary event, indistinguishable from a stated one. | Hour, Gift, Owl, Window, Necklace | `status`, `reported_by` |
| Causes between events. | all six | `causes`, `explains` |
| Habits and repeated events; a stretch told as a summary. | Gift, Necklace, Yellow | `frequency: iterative`, `mode: summarised`, `duration` |
| The history of a state that changes (a feeling, a hair length, a holder). v1 keeps the current state; the old one is lost. | all six | `states` with `from`/`until` |
| Unnamed people and places that must exist for things to change hands. | Gift, Window, Necklace, Yellow | `unnamed`, no place plus `place_note` |
| An item whose whereabouts are unknown, or that is thrown to another place. | Necklace, Yellow | holder `unknown`, `effects move` |
| A conditional agreement with a deadline, and what was given up. | Necklace | `terms`, `expires`, `foregoes` |
| The narrator's or a character's interpretation as distinct from fact. | all six | `readings` |
| What was said (v1 keeps what the listener took in). | all six | `says` |
| A life-or-death state; an animal. | Hour; Window | `states` of kind `life`; `kind: animal` |

## Where v1 held its own

- **Numbers that change.** `variables` and `variable_changes` hold cash and debt exactly (Gift, Necklace). Relationship values move and can be read back as a series: in the Yellow Wall Paper, trust in John falls from 0.6 to 0.2 across the summer, and v1 answers that question where v2, which has only free text for it, does not.
- **Things and who has them.** The item rules (a thing has one holder; to hand something over both people must be in the room) caught real mistakes: the first Gift history failed until the move was its own edit.
- **Who may know a secret.** `known_by` on lore holds a hidden truth (the paste necklace, the lie behind the ghost story) without any new field.
- **What a person took in.** Perception `content` with `accuracy` is the right home for what a listener took from a speech, and it worked for misreadings (Window), partial hearing (Owl) and what someone could not read in a face (Gift).
- **Loaders and the parser as a check.** Both enforce references and shapes; a typo in a place, character or item key fails at once. `validate.spec.ts` uses them.

## What v2 still cannot do

- **Numeric relationships.** There is no equivalent of v1's trust and tension values (Yellow, `q11`).
- **Concealment as a relation.** Hiding a diary, wakefulness, a vision is the engine of the Yellow Wall Paper, and v2 holds it as a state and as `unaware` rows, not as an act of someone toward someone.
- **A performance against a feeling** (Vera's acted horror in The Open Window): only a note.
- **Skills and dispositions** (Della's ability to read her reflection in strips, Framton's belief that strangers want his symptoms): states of free text.
- **Exact wording.** `says` keeps the content, sometimes verbatim, not the voice.
- **Descriptive detail** of places, objects and smells: states of free text. A place has no list of features in v2.
- **Totals with a gap.** A debt "paid in full, amount not given" and a price never told (the watch) cannot be summed.
- **Several narrators or time frames at once**, and **simultaneity** (Jim's afternoon runs beside Della's in Gift; v2 can say the order is not known, not that two things were at the same time).

## Questions for the decision

These need a person to decide; none is answered by the files.

1. Does the store keep an event's own time (instant, interval, relative), or does the clock stay the only source and the rest stays text?
2. Is truth a separate thing (`facts`), or only a property of what someone perceived (`accuracy`)? The first lets a reader or a second character check a belief; the second is what we have.
3. Are non-actual events one mechanism (frames), or do we handle them one by one (plans, hooks and triggers are already futures; a vision, a told story and a counterfactual are not)?
4. Is the telling track part of the store, or only the part that matters for play: what the player has been told, which is a reader's `knowledge` with `reveals` and `withholds`?
5. How does `status: implied/reported` relate to the commitment status the generative workflow needs (outline, played, off-screen, backfilled)? They look like one field.
6. Which of the "cannot do" items matter for roleplay, as opposed to for modelling fiction?
